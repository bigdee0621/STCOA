﻿using System;
using System.Collections.Generic;

namespace STCOA.EnityModel
{
    public partial class SysPosition
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Department { get; set; }
    }
}
