﻿namespace STCOA.Controllers
{
    public class ApplicationDbContext
    {
    }
}